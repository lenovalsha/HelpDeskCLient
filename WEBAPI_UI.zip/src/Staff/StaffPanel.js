import Tickets from "./Tickets";
import Chat from "./Chat";
import Navbar from "./Navbar";

function StaffPanel()
{

    return(
        <div className="application">
        <Navbar/>
        <div className="container">
        </div>
        </div>
        
    )
}
export default StaffPanel;